# Online multiplayer implementation status

Current build: **not implemented**. The generated club scene is a local visual prototype only.

Recommended production architecture:
1. Netcode for GameObjects + Unity Transport for synchronized player avatars and emotes.
2. Unity Authentication for player identity.
3. Unity Lobby for room discovery/invites.
4. Unity Relay for peer connectivity without exposing player IP addresses.
5. Server-authoritative match timer, scoring, rewards, and anti-cheat validation.
6. Backend persistence for accounts, inventory, rankings, and moderation.
7. Voice chat only after privacy, reporting, blocking, and age-safety requirements are designed.

Before public release, test at least two physical devices on separate networks, disconnect/reconnect, latency, host departure, room capacity, and server-side score validation.
