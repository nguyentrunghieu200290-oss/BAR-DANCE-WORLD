using UnityEngine;

namespace BarDanceWorld
{
    /// <summary>Creates a lightweight neon club prototype from built-in primitives.</summary>
    public class BarDanceWorldScene : MonoBehaviour
    {
        [ContextMenu("Build Club Environment")]
        public void BuildEnvironment()
        {
            if (transform.childCount > 0) return;

            Material floor = MakeMat("Midnight floor", new Color(.025f,.035f,.09f), .65f, .25f);
            Material dark = MakeMat("Dark metal", new Color(.07f,.08f,.13f), .7f, .2f);
            Material cyan = MakeMat("Neon cyan", new Color(.02f,.8f,1f), .25f, .75f);
            Material pink = MakeMat("Neon magenta", new Color(1f,.03f,.42f), .25f, .75f);
            Material gold = MakeMat("Warm gold", new Color(1f,.48f,.08f), .3f, .55f);

            Cube("Main dance floor", new Vector3(0, -.25f, 0), new Vector3(22,.5f,18), floor);
            Cube("Raised stage", new Vector3(0,.15f,6.5f), new Vector3(12,.8f,3), dark);
            Cube("Back wall", new Vector3(0,5,9), new Vector3(22,10,.5f), dark);
            Cube("Left wall", new Vector3(-11,4,0), new Vector3(.5f,8,18), dark);
            Cube("Right wall", new Vector3(11,4,0), new Vector3(.5f,8,18), dark);

            for (int i=0;i<8;i++)
            {
                float x = -8.5f + i*2.43f;
                Cube("Floor light strip", new Vector3(x,.02f,-1), new Vector3(.055f,.025f,12), i%2==0?cyan:pink);
            }
            for (int i=0;i<5;i++)
            {
                float x = -8f + i*4f;
                Cube("Stage LED", new Vector3(x,.65f,4.9f), new Vector3(2.8f,.12f,.08f), i%2==0?pink:cyan);
                Cylinder("Dance podium", new Vector3(x,.35f,2.4f), new Vector3(1.15f,.35f,1.15f), gold);
            }
            for (int i=0;i<6;i++)
            {
                float x = -8f + i*3.2f;
                Cube("Ceiling beam", new Vector3(x,8,0), new Vector3(.18f,.18f,18), cyan);
                PointLight("Club spotlight", new Vector3(x,7,3), i%2==0?new Color(.1f,.55f,1f):new Color(1f,.05f,.35f), 7, 16);
            }

            for (int i=0;i<4;i++)
            {
                var dancer = GameObject.CreatePrimitive(PrimitiveType.Capsule);
                dancer.name = "Prototype dancer " + (i+1);
                dancer.transform.SetParent(transform);
                dancer.transform.position = new Vector3(-4.5f+i*3f,1f,-3f);
                dancer.transform.localScale = new Vector3(.65f,1f,.65f);
                dancer.GetComponent<Renderer>().material = i%2==0?cyan:pink;
            }

            var cameraObject = new GameObject("Prototype Camera");
            cameraObject.transform.SetParent(transform);
            cameraObject.transform.position = new Vector3(0,10,-16);
            cameraObject.transform.rotation = Quaternion.Euler(25,0,0);
            var cam = cameraObject.AddComponent<Camera>();
            cam.fieldOfView = 58;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(.008f,.01f,.035f);
            cameraObject.AddComponent<AudioListener>();

            var lightObject = new GameObject("Ambient club light");
            lightObject.transform.SetParent(transform);
            var ambient = lightObject.AddComponent<Light>();
            ambient.type = LightType.Directional;
            ambient.intensity = .45f;
            ambient.color = new Color(.45f,.55f,1f);
            lightObject.transform.rotation = Quaternion.Euler(50,-30,0);
        }

        GameObject Cube(string n, Vector3 p, Vector3 s, Material m)
        {
            var g=GameObject.CreatePrimitive(PrimitiveType.Cube);
            g.name=n; g.transform.SetParent(transform); g.transform.position=p; g.transform.localScale=s;
            g.GetComponent<Renderer>().material=m; return g;
        }
        GameObject Cylinder(string n, Vector3 p, Vector3 s, Material m)
        {
            var g=GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            g.name=n; g.transform.SetParent(transform); g.transform.position=p; g.transform.localScale=s;
            g.GetComponent<Renderer>().material=m; return g;
        }
        void PointLight(string n, Vector3 p, Color c, float intensity, float range)
        {
            var g=new GameObject(n); g.transform.SetParent(transform); g.transform.position=p;
            var l=g.AddComponent<Light>(); l.type=LightType.Point; l.color=c; l.intensity=intensity; l.range=range;
        }
        Material MakeMat(string n, Color c, float metallic, float smooth)
        {
            var shader=Shader.Find("Universal Render Pipeline/Lit");
            if (shader==null) shader=Shader.Find("Standard");
            var m=new Material(shader); m.name=n;
            if (m.HasProperty("_BaseColor")) m.SetColor("_BaseColor",c);
            if (m.HasProperty("_Color")) m.SetColor("_Color",c);
            if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic",metallic);
            if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness",smooth);
            if (m.IsKeywordEnabled("_EMISSION") || m.HasProperty("_EmissionColor"))
            {
                m.EnableKeyword("_EMISSION");
                m.SetColor("_EmissionColor",c*1.8f);
            }
            return m;
        }
    }
}
