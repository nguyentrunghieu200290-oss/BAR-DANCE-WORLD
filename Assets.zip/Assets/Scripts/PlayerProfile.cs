using System;
using UnityEngine;

namespace BarDanceWorld
{
    [Serializable]
    public class PlayerProfile
    {
        public string displayName = "New Dancer";
        [Min(1)] public int level = 1;
        [Min(0)] public int experience;
        [Min(0)] public int coins = 1000;

        public void AddExperience(int amount)
        {
            if (amount <= 0) return;
            experience = Mathf.Min(int.MaxValue - amount, experience) + amount;
            while (experience >= level * 100 && level < 999)
            {
                experience -= level * 100;
                level++;
            }
        }
    }
}
