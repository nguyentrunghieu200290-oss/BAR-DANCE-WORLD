using UnityEngine;

namespace BarDanceWorld
{
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }
        [SerializeField, Min(0)] private int startingCoins = 1000;
        public int Coins { get; private set; }

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            Coins = Mathf.Max(0, startingCoins);
        }

        public void AddCoins(int amount)
        {
            if (amount > 0) Coins = amount > int.MaxValue - Coins ? int.MaxValue : Coins + amount;
        }

        public bool TrySpendCoins(int amount)
        {
            if (amount <= 0 || Coins < amount) return false;
            Coins -= amount;
            return true;
        }
    }
}
