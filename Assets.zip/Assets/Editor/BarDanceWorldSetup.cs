#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.IO;

namespace BarDanceWorld.Editor
{
    public static class BarDanceWorldSetup
    {
        [MenuItem("BAR DANCE WORLD/Create Prototype Scene")]
        public static void CreateScene()
        {
            const string folder = "Assets/Scenes";
            if (!AssetDatabase.IsValidFolder(folder))
                AssetDatabase.CreateFolder("Assets", "Scenes");

            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var root = new GameObject("BAR DANCE WORLD");
            root.AddComponent<BarDanceWorldScene>().BuildEnvironment();

            var manager = new GameObject("Game Manager");
            manager.AddComponent<BarDanceWorld.GameManager>();

            var path = folder + "/BarDanceWorld.unity";
            EditorSceneManager.SaveScene(scene, path);
            AssetDatabase.SaveAssets();
            EditorUtility.DisplayDialog("BAR DANCE WORLD",
                "Prototype scene created at " + path + ". Open it and press Play.", "OK");
        }
    }
}
#endif
