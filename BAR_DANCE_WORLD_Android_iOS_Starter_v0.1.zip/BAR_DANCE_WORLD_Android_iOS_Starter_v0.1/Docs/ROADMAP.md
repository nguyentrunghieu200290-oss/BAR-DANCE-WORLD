# Development roadmap

1. Build a playable offline vertical slice: third-person controller, one venue, avatar,
   dance animation set, beat chart, scoring UI, and mobile touch controls.
2. Add backend identity, persistence, matchmaking, and authoritative game sessions.
3. Implement 5v5 rooms and reconnect/error handling.
4. Integrate licensed real-time voice chat and safety/moderation controls.
5. Design the virtual currency/shop economy and secure payment flows.
6. Add admin tooling, analytics, privacy/security review, device testing, and release pipeline.

Do not represent placeholder/local prototype logic as online functionality.
