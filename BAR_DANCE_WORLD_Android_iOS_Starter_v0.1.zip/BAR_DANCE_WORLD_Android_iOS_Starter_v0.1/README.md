# BAR DANCE WORLD — Unity Starter v0.1

This is a **starter source project**, not a finished game and not a built APK/IPA.
Target: Android and iOS. Engine baseline: Unity 6 (6000.0).

## Included
- Unity project folder structure
- Local player profile with XP and level progression
- Basic rhythm-timing score prototype
- Five sample bar/venue entries
- Setup and development notes

## Not included / not implemented
Online multiplayer or 5v5 matchmaking, real voice chat, live servers, accounts,
cloud saves, payments/top-ups, gold/diamond economy, moderation/admin tools,
finished 3D characters/environments/animations, licensed music, or production builds.
These require additional implementation, services, testing, and platform accounts.

## Open in Unity
1. Download and unzip this archive.
2. In Unity Hub, choose **Add** and select this folder.
3. Open with a Unity 6 editor (6000.0).
4. Create a scene named `Main` under `Assets/Scenes` if one is not present.
5. Add an empty GameObject named `GameManager` and attach `GameManager.cs`.
6. Press Play. The prototype logic is available from the component Inspector/context menu
   and can be connected to UI and input in the next development phase.

## Mobile builds
Set Android or iOS as the target in Build Profiles after installing the relevant Unity
modules. An iOS build still needs macOS/Xcode signing and Apple Developer provisioning
to distribute through TestFlight. This ZIP itself does not perform a cloud build.
