using UnityEngine;

public static class RhythmScoring
{
    // deltaSeconds is the absolute timing difference from the beat, in seconds.
    public static int Score(float deltaSeconds)
    {
        float error = Mathf.Abs(deltaSeconds);
        if (error <= 0.075f) return 100; // Perfect
        if (error <= 0.150f) return 75;  // Great
        if (error <= 0.250f) return 50;  // Good
        return 0;                        // Miss
    }
}
