using UnityEngine;

public class GameManager : MonoBehaviour
{
    [Header("Local prototype profile")]
    public PlayerProfile profile = new PlayerProfile();

    public int totalDanceScore { get; private set; }

    public void RegisterDanceHit(float secondsFromBeat)
    {
        int points = RhythmScoring.Score(secondsFromBeat);
        totalDanceScore += points;
        profile.AddXP(points / 10);
        Debug.Log($"Dance hit: {points} points | Total: {totalDanceScore} | Level: {profile.level}");
    }

    [ContextMenu("Prototype/Test Perfect Beat")]
    private void TestPerfectBeat() => RegisterDanceHit(0.02f);

    [ContextMenu("Prototype/Test Missed Beat")]
    private void TestMissedBeat() => RegisterDanceHit(0.35f);
}
