using System;
using UnityEngine;

[Serializable]
public class PlayerProfile
{
    public string playerName = "Dancer";
    public int level = 1;
    public int xp = 0;

    public int XPToNextLevel => Mathf.Max(100, level * 100);

    public void AddXP(int amount)
    {
        if (amount <= 0) return;
        xp += amount;
        while (xp >= XPToNextLevel)
        {
            xp -= XPToNextLevel;
            level++;
        }
    }
}
