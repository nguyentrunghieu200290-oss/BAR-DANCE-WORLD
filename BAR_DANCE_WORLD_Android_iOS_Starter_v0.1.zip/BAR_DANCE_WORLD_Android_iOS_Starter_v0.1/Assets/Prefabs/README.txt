Place character, venue, UI, and gameplay prefabs here as they are created.
