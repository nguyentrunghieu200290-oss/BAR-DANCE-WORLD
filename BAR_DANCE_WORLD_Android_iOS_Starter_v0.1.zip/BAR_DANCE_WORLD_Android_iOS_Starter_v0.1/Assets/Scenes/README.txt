Create the Unity scene(s) here. The starter archive intentionally contains no finished 3D scene assets.
